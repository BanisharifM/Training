import numpy as np

a = np.array([1, 2, 3, 4])
print(a)

a=np.random.randn(3,3)
b=np.random.randn(3,1)
c=a*b
print(c)