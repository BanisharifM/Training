# (≈ 1 line of code)
# test =
# YOUR CODE STARTS HERE
test = "Hello World"

# YOUR CODE ENDS HERE
print("test: " + test)
