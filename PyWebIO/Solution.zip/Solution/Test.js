alert("hello world!");
